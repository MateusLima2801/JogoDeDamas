#ifndef GLOBAL_H
#define GLOBAL_H
#include ".\Board\Color.h"

const int Dim = 8;
const int AmtPieces = 3*Dim;

//BRASIL: DIMENSION 8 AND 24 PIECES
//MUNDO: DIMENSION 10 AND 30 PIECES
#endif