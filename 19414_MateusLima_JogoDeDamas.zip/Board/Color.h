#ifndef COLOR_H
#define COLOR_H

enum Color
{
    emptyColor,
    black,
    white
};

#endif